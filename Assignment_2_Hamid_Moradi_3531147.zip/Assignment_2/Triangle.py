import pygame
from Shape import Shape
import random

class Triangle(Shape):
    def __init__(self, window, maxWidth, maxHeight):
        super().__init__(window, 'Triangle', maxWidth, maxHeight)
        self.height = random.randint(30, 100)
        self.width = random.randint(30, 100)

    def clickedInside(self, mousePoint):
        # Check if the point is inside the triangle
        # For simplicity, I'll use a rectangular bounding box
        points = [
            (self.x, self.y - self.height),
            (self.x - self.width / 2, self.y + self.height / 2),
            (self.x + self.width / 2, self.y + self.height / 2)
        ]

        # Check if the mouse click is inside the bounding box
        return (
            min(p[0] for p in points) <= mousePoint[0] <= max(p[0] for p in points) and
            min(p[1] for p in points) <= mousePoint[1] <= max(p[1] for p in points)
        )

    def getShapeType(self):
        return self.shapeType

    def calculateArea(self):
        return 0.5 * self.width * self.height

    def draw(self):
        points = [
            (self.x, self.y - self.height),
            (self.x - self.width / 2, self.y + self.height / 2),
            (self.x + self.width / 2, self.y + self.height / 2)
        ]
        pygame.draw.polygon(self.window, self.color, points)
