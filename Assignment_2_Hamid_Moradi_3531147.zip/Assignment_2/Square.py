import sndhdr
import pygame
from Shape import Shape  # Import the base Shape class
import random

class Square(Shape):
    def __init__(self, window, maxWidth, maxHeight):
        super().__init__(window, 'Square', maxWidth, maxHeight)  # Initialize as a Square
        # Define width and height for the Square
        self.width = random.randint(30, 100)
        self.height = self.width  # A square has equal width and height

    def clickedInside(self, mousePoint):
        # Implement click check logic for squares
        # For simplicity, we'll check if the point is inside the square's bounding box
        return (self.x <= mousePoint[0] <= self.x + self.width) and (self.y <= mousePoint[1] <= self.y + self.height)

    def calculateArea(self):
        # Implement area calculation for squares
        return self.width * self.height

    def draw(self):
        # Implement drawing logic for squares
        pygame.draw.rect(self.window, self.color, (self.x, self.y, self.width, self.height))

    def getShapeType(self):
        # Implement the method to return the shape type
        return self.shapeType
