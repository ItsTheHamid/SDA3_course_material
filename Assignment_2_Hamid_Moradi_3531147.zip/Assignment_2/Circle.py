import pygame
from Shape import Shape
import random


class Circle(Shape):
    def __init__(self, window, maxWidth, maxHeight):
        super().__init__(window, 'Circle', maxWidth, maxHeight)
        self.radius = random.randint(20, 50)

    def clickedInside(self, mousePoint):
        distance = ((mousePoint[0] - self.x) ** 2 + (mousePoint[1] - self.y) ** 2) ** 0.5
        return distance <= self.radius

    def getShapeType(self):
        return self.shapeType

    def calculateArea(self):
        return 3.1416 * (self.radius ** 2)

    def draw(self):
        pygame.draw.circle(self.window, self.color, (self.x, self.y), self.radius)
