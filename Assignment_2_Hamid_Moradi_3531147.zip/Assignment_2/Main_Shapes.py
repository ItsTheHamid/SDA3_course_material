import pygame
from Shape import Shape
from Circle import Circle
from Triangle import Triangle
from Square import Square

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
BACKGROUND_COLOR = (0, 0, 0)  # Black background

# Initialize Pygame
pygame.init()
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Shapes Example")

# Create shapes
shapes = []

for _ in range(2):
    shapes.append(Circle(window, WINDOW_WIDTH, WINDOW_HEIGHT))

for _ in range(2):
    shapes.append(Triangle(window, WINDOW_WIDTH, WINDOW_HEIGHT))

for _ in range(2):
    shapes.append(Square(window, WINDOW_WIDTH, WINDOW_HEIGHT))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            for s in shapes:
                if s.clickedInside(event.pos):
                    color = s.getColor()
                    print(f"Clicked a {s.getShapeType()} of color {color} at position ({s.x}, {s.y}), Area: {s.calculateArea():.2f}")

    window.fill(BACKGROUND_COLOR)
    for s in shapes:
        s.draw()
    pygame.display.flip()

pygame.quit()
