import pygame
from abc import ABC, abstractmethod
import random


class Shape(ABC):
   
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)


    def __init__(self, window, shapeType, maxWidth, maxHeight):
        self.window = window
        self.shapeType = shapeType
        self.color = random.choice([Shape.RED, Shape.GREEN, Shape.BLUE])
        self.x = random.randint(0, maxWidth)
        self.y = random.randint(0, maxHeight)

    @abstractmethod
    def clickedInside(self, mousePoint):
        raise NotImplementedError

    @abstractmethod
    def getShapeType(self):
        raise NotImplementedError

    @abstractmethod
    def calculateArea(self):
        raise NotImplementedError

    def draw(self):
        pass  # This method can be left empty in the base class

    def getColor(self):
        return self.color
