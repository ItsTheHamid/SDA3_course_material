from PIL import Image, ImageDraw
import time

# Load image
image = Image.open('C:\\Users\\Hamid Moradi\\Desktop\\audicar.jpg')

# Check dimensions
min_width = 1800
min_height = 1400

if image.width < min_width or image.height < min_height:
    print("Error: The image dimensions should be at least 1800x1400.")
else:
    # Display the original image for 3 seconds
    image.show()
    time.sleep(3)

    # Create a copy of the original image to prevent closing it prematurely - bugfix
    resized_image = image.copy()
    resized_image = resized_image.resize((int(image.width * 0.6), int(image.height * 0.6)))
    resized_image.show()
    time.sleep(3)

    # Convert the resized image to grayscale
    grayscale_image = resized_image.convert('L')
    grayscale_image.show()
    time.sleep(3)

    # Crop the resized image to size 400x400 starting at (20, 20)
    cropped_image = resized_image.crop((20, 20, 420, 420))

    draw = ImageDraw.Draw(cropped_image)

    # Draw a yellow circle in the top-left corner
    draw.ellipse((20, 20, 40, 40), outline='yellow', width=2)

    # Display
    cropped_image.show()
    time.sleep(3)

    # Draw a blue filled ellipse in the top-right corner
    draw.ellipse((360, 20, 435, 60), outline='blue', fill='blue')

    # Display
    cropped_image.show()
    time.sleep(3)

    # Draw an unfilled square in the bottom-left corner
    draw.rectangle((20, 360, 65, 405), outline=(192, 75, 15), width=1)

    # Display
    cropped_image.show()
    time.sleep(3)

    # Draw a filled square in the bottom-right corner
    draw.rectangle((335, 335, 380, 380), fill=(192, 75, 15))

    # Display
    cropped_image.show()
    time.sleep(3)