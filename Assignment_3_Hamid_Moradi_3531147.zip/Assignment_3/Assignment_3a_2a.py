import cv2
import datetime

cap = cv2.VideoCapture(0)  

# Define the codec, file name, and create object to save the video
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Codec 
current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
output_file = f'output_{current_time}.avi'
out = cv2.VideoWriter(output_file, fourcc, 20.0, (640, 480))  # Frame size and frame rate

# Record and display the stream for 5 seconds
start_time = datetime.datetime.now()
while (datetime.datetime.now() - start_time).seconds < 5:
    ret, frame = cap.read()  
    if not ret:
        break
    out.write(frame)  
    cv2.imshow('Video Stream', frame)  # Display
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

out.release()
cv2.destroyAllWindows()
