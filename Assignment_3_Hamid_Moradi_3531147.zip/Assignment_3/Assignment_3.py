import cv2
import numpy as np

def get_contour_name(approx):
    # Determine the shape based on the number of vertices
    if len(approx) == 3:
        return "Triangle"
    elif len(approx) == 4:
        return "Square"
    else:
        return "Circle"

# Minimum area for object detection so there are not too many false readings
MIN_AREA = 100 * 100

# Initialize camera
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Convert the frame to grayscale for shape detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, thresholded = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY)

    # Find contours
    contours, _ = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Initialize the object name 
    object_name = "Unknown"
    centroid = None

    for contour in contours:
        area = cv2.contourArea(contour)

        if area >= MIN_AREA:
            # Get the centroid of the object
            M = cv2.moments(contour)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                centroid = (cX, cY)

                # Approximate the shape
                epsilon = 0.04 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                object_name = get_contour_name(approx)

                # Draw a box around the object
                x, y, w, h = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # Draw the shape name at the centroid
                cv2.putText(frame, object_name, (cX - 20, cY - 20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

                # Draw a dot at the centroid
                cv2.circle(frame, (cX, cY), 5, (0, 0, 255), -1)

    cv2.imshow('Object Detection', frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
