import cv2
import os

# Directory
video_dir = 'D:\\Cleanup\\Fontys\\UNI\\ASSIGNMENTS\\Y2Q1\\SDA\\SDA repo\\SDA3_course_material\\Assignment_3'

video_files = [f for f in os.listdir(video_dir) if f.endswith('.avi')]

# Find the most recent video file
if video_files:
    most_recent_file = max(video_files, key=lambda x: os.path.getctime(os.path.join(video_dir, x)))
    video_file = os.path.join(video_dir, most_recent_file)
else:
    print("No video files found in the directory.")
    exit()

# Open video file
cap = cv2.VideoCapture(video_file)

if not cap.isOpened():
    print("Error: Could not open video file")
    exit()

# Display
while True:
    ret, frame = cap.read()
    
    if not ret:
        break
    
    cv2.imshow('Video Footage', frame)
    
    # 'q' to exit 
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# All close
cap.release()
cv2.destroyAllWindows()
