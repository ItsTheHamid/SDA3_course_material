import pygame
from pygame.locals import *
import sys
import random

class Ball:
    def __init__(self, screen, image_path, x, y, speed_x, speed_y):
        self.screen = screen
        self.image = pygame.image.load(image_path)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed_x = speed_x
        self.speed_y = speed_y

    def move(self):
        self.rect.x += self.speed_x
        self.rect.y += self.speed_y

        if self.rect.left < 0 or self.rect.right > self.screen.get_width():
            self.speed_x = -self.speed_x

        if self.rect.top < 0 or self.rect.bottom > self.screen.get_height():
            self.speed_y = -self.speed_y

    def draw(self):
        self.screen.blit(self.image, self.rect)

def main():
    pygame.init()


    width, height = 800, 600
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Moving Lebron James Ball")

    width_100, height_100 = 700, 500
    ball_image_path = "bball.png"
    ball_x = random.randint(100, width_100)
    ball_y = random.randint(100, height_100)
    ball_speed_x = random.choice([-4, -3, -2, -1, 1, 2, 3, 4])
    ball_speed_y = random.choice([-4, -3, -2, -1, 1, 2, 3, 4])

    ball = Ball(screen, ball_image_path, ball_x, ball_y, ball_speed_x, ball_speed_y)

    clock = pygame.time.Clock()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill((0, 0, 0)) 

        ball.move()
        ball.draw()

        pygame.display.flip()
        clock.tick(30) 

if __name__ == "__main__":
    main()
