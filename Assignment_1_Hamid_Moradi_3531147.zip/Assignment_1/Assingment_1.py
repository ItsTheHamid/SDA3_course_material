import pygame
import random
import math

# Initialize pygame
pygame.init()

# Constants
WINDOW_WIDTH = 1000
WINDOW_HEIGHT = 1000
N_SHAPES = 5 # Number of shapes
SHAPE_COLORS = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # Red, Green, Blue
BACKGROUND_COLOR = (0, 0, 0)  # Black 


class Circle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.radius = random.randint(20, 50)

    def draw(self, window):
        pygame.draw.circle(window, self.color, (self.x, self.y), self.radius)

    def getType(self):
        return "Circle"

    def getArea(self):
        return math.pi * self.radius ** 2

    def clickedInside(self, pos):
        distance = math.sqrt((self.x - pos[0]) ** 2 + (self.y - pos[1]) ** 2)
        return distance <= self.radius


class Rectangle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.width = random.randint(30, 100)
        self.height = random.randint(30, 100)

    def draw(self, window):
        pygame.draw.rect(window, self.color, (self.x, self.y, self.width, self.height))

    def getType(self):
        return "Rectangle"

    def getArea(self):
        return self.width * self.height

    def clickedInside(self, pos):
        return (self.x <= pos[0] <= self.x + self.width and
                self.y <= pos[1] <= self.y + self.height)


class Triangle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.width = random.randint(30, 100)
        self.height = random.randint(30, 100)

    def draw(self, window):
        points = [(self.x, self.y - self.height),
                  (self.x - self.width / 2, self.y + self.height / 2),
                  (self.x + self.width / 2, self.y + self.height / 2)]
        pygame.draw.polygon(window, self.color, points)

    def getType(self):
        return "Triangle"

    def getArea(self):
        return 0.5 * self.width * self.height

    def clickedInside(self, pos):
        # Check if the point is inside the triangle 
        points = [(self.x, self.y - self.height),
                  (self.x - self.width / 2, self.y + self.height / 2),
                  (self.x + self.width / 2, self.y + self.height / 2)]
        return pygame.draw.polygon(window, self.color, points).collidepoint(pos)

# Create window
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Shape Clicker")

shapesList = []
for _ in range(N_SHAPES):
    x = random.randint(0, WINDOW_WIDTH)
    y = random.randint(0, WINDOW_HEIGHT)
    color = random.choice(SHAPE_COLORS)
    shape_type = random.choice([Circle, Rectangle, Triangle])
    shapesList.append(shape_type(x, y, color))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            for shape in shapesList:
                if shape.clickedInside(event.pos):
                    print(f"Clicked {shape.getType()} at position ({shape.x}, {shape.y}), Area: {shape.getArea():.2f}")
                    break

    window.fill(BACKGROUND_COLOR)
    for shape in shapesList:
        shape.draw(window)
    pygame.display.flip()

pygame.quit()
